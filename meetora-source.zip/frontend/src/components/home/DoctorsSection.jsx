import React, { useState, useEffect } from "react";
import {
  Search,
  MapPin,
  Filter,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  RefreshCw,
} from "lucide-react";

import { Link } from "react-router-dom";
import DoctorCard from "./DoctorCard";
import { publicApi } from "../../api/publicApi";

export default function DoctorsSection() {
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [currentPage, setCurrentPage] = useState(1);
  const [lastPage, setLastPage] = useState(1);
  const [totalDoctors, setTotalDoctors] = useState(0);

  const [selectedSpecialty, setSelectedSpecialty] = useState("All");
  const [searchTerm, setSearchTerm] = useState("");
  const [locationTerm, setLocationTerm] = useState("");

  const specialties = [
    "All",
    "General Practitioner",
    "Cardiologist",
    "Dermatologist",
    "Pediatrician",
    "Neurologist",
    "Ophthalmologist",
  ];

  const fetchDoctors = async (page = 1) => {
    try {
        setLoading(true);
        setError(null);

        const response = await publicApi.getDoctors(page);

        console.log("DOCTORS RESPONSE:", response.data);

        const data = response.data?.data || [];
        const meta = response.data?.meta;

        setDoctors(data);

        if (meta) {
          setCurrentPage(meta.current_page);
          setLastPage(meta.last_page);
          setTotalDoctors(meta.total);
        }
      } catch (err) {
        console.error("Failed to fetch doctors:", err);
        console.error("API ERROR:", err.response?.data);

        setError(
          err.response?.data?.message ||
          "Unable to load doctors from server. Please try again."
        );
      } finally {
        setLoading(false);
      }
    };
  useEffect(() => {
    fetchDoctors();
  }, []);

  // ==========================================
  // Filter Doctors
  // ==========================================
  const filteredDoctors = doctors.filter((doc) => {
    const docSpecialty =
      doc.specialty?.name || doc.specialty_name || doc.specialty || "";

    const docName =
      doc.name ||
      (doc.user
        ? `${doc.user.first_name || ""} ${doc.user.last_name || ""}`
        : "");

    const docCity = doc.city || doc.location || doc.address || "";

    const matchesSpecialty =
      selectedSpecialty === "All" ||
      docSpecialty.toLowerCase() === selectedSpecialty.toLowerCase();

    const matchesSearch =
      docName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      docSpecialty.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesLocation = docCity
      .toLowerCase()
      .includes(locationTerm.toLowerCase());

    return matchesSpecialty && matchesSearch && matchesLocation;
  });

  // ==========================================
  // Reset Filters
  // ==========================================
  const resetFilters = () => {
    setSearchTerm("");
    setLocationTerm("");
    setSelectedSpecialty("All");
  };
  const handlePageChange = (page) => {
    if (page < 1 || page > lastPage || page === currentPage) {
      return;
    }

    fetchDoctors(page);

    document.getElementById("doctors")?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  };
  return (
    <section id="doctors" className="bg-[#F8FAFC] py-16">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* ==========================================
            HEADER
        ========================================== */}

        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-5 mb-10">
          <div>
            <div
              className="
                inline-flex items-center
                px-3 py-1
                rounded-full
                bg-[#EEF2FF]
                border border-[#E0E7FF]
                text-xs font-semibold
                text-[#3F38CA]
                mb-3
              "
            >
              Medical Team
            </div>

            <h2
              className="
                text-3xl sm:text-4xl
                font-extrabold
                text-[#0F172A]
                tracking-tight
              "
            >
              Top Rated Practitioners
            </h2>

            <p
              className="
                text-[#475569]
                text-sm
                mt-2
                max-w-xl
                leading-relaxed
              "
            >
              Connect with certified healthcare experts. Filter by specialty,
              search by name, and schedule consultations.
            </p>
          </div>

          <Link
            to="/doctors"
            className="
              inline-flex items-center gap-2
              text-sm font-semibold
              text-[#3F38CA]
              hover:text-[#312E81]
              transition-colors
              shrink-0
            "
          >
            Browse All Doctors
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {/* ==========================================
            SEARCH & FILTERS
        ========================================== */}

        <div
          className="
            bg-white
            rounded-2xl
            border border-[#E2E8F0]
            p-4
            shadow-sm
            mb-8
            space-y-4
          "
        >
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            {/* Search */}
            <div
              className="
                md:col-span-6
                h-11
                flex items-center
                bg-[#F8FAFC]
                border border-[#E2E8F0]
                rounded-xl
                px-4
                focus-within:border-[#3F38CA]
                focus-within:ring-2
                focus-within:ring-[#3F38CA]/10
                transition-all
              "
            >
              <Search
                className="
                  w-4 h-4
                  text-[#94A3B8]
                  mr-2.5
                  shrink-0
                "
              />

              <input
                type="text"
                placeholder="Search by doctor name or specialty..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="
                  w-full
                  bg-transparent
                  text-sm
                  text-[#0F172A]
                  outline-none
                  placeholder:text-[#94A3B8]
                "
              />
            </div>

            {/* Location */}
            <div
              className="
                md:col-span-4
                h-11
                flex items-center
                bg-[#F8FAFC]
                border border-[#E2E8F0]
                rounded-xl
                px-4
                focus-within:border-[#3F38CA]
                focus-within:ring-2
                focus-within:ring-[#3F38CA]/10
                transition-all
              "
            >
              <MapPin
                className="
                  w-4 h-4
                  text-[#94A3B8]
                  mr-2.5
                  shrink-0
                "
              />

              <input
                type="text"
                placeholder="City or state..."
                value={locationTerm}
                onChange={(e) => setLocationTerm(e.target.value)}
                className="
                  w-full
                  bg-transparent
                  text-sm
                  text-[#0F172A]
                  outline-none
                  placeholder:text-[#94A3B8]
                "
              />
            </div>

            {/* Reset */}
            <div className="md:col-span-2">
              <button
                type="button"
                onClick={resetFilters}
                className="
                  w-full h-11
                  bg-white
                  border border-[#E2E8F0]
                  hover:bg-[#F8FAFC]
                  text-[#475569]
                  hover:text-[#3F38CA]
                  text-xs font-semibold
                  rounded-xl
                  flex items-center
                  justify-center
                  gap-2
                  transition-all
                "
              >
                <Filter className="w-4 h-4" />
                Reset Filters
              </button>
            </div>
          </div>

          {/* ==========================================
              SPECIALTIES
          ========================================== */}

          <div
            className="
              flex items-center gap-2
              overflow-x-auto
              pb-1 pt-1
              no-scrollbar
            "
          >
            {specialties.map((spec) => (
              <button
                key={spec}
                type="button"
                onClick={() => setSelectedSpecialty(spec)}
                className={`
                  px-4 h-9
                  rounded-xl
                  text-xs
                  font-semibold
                  whitespace-nowrap
                  border
                  transition-all
                  ${
                    selectedSpecialty === spec
                      ? `
                        bg-[#3F38CA]
                        border-[#3F38CA]
                        text-white
                        shadow-sm
                      `
                      : `
                        bg-[#F8FAFC]
                        border-[#E2E8F0]
                        text-[#475569]
                        hover:text-[#3F38CA]
                        hover:border-[#C7D2FE]
                        hover:bg-[#EEF2FF]
                      `
                  }
                `}
              >
                {spec}
              </button>
            ))}
          </div>
        </div>

        

        {/* ==========================================
            ERROR
        ========================================== */}

        {!loading && error && (
          <div
            className="
              bg-white
              rounded-2xl
              border border-[#FCA5A5]
              p-10
              text-center
              shadow-sm
              max-w-lg
              mx-auto
            "
          >
            <p
              className="
                text-sm
                font-medium
                text-[#DC2626]
                mb-4
              "
            >
              {error}
            </p>

            <button
              type="button"
              onClick={fetchDoctors}
              className="
                h-10 px-4
                inline-flex
                items-center
                justify-center
                gap-2
                bg-[#3F38CA]
                hover:bg-[#312E81]
                text-white
                text-xs
                font-semibold
                rounded-xl
                transition-all
              "
            >
              <RefreshCw className="w-4 h-4" />
              Retry
            </button>
          </div>
        )}

        {/* ==========================================
            DOCTORS
        ========================================== */}

        {!loading && !error && filteredDoctors.length > 0 && (
          <div
            className="
                grid grid-cols-1
                sm:grid-cols-2
                lg:grid-cols-3
                gap-6
              "
          >
            {filteredDoctors.map((doc) => {
              // Debug
              console.log(`Doctor ${doc.id} - ${doc.name}:`, doc.image);

              const formattedDoctor = {
                id: doc.id,

                name:
                  doc.name ||
                  (doc.user
                    ? `Dr. ${doc.user.first_name || ""} ${
                        doc.user.last_name || ""
                      }`
                    : "Dr. Medical Expert"),

                specialty:
                  doc.specialty?.name ||
                  doc.specialty_name ||
                  doc.specialty ||
                  "General Practitioner",

                city:
                  doc.city ||
                  doc.location ||
                  doc.address ||
                  "Consultation Center",

                rating: doc.rating || 4.9,

                reviews: doc.reviews_count || doc.reviews || 120,

                experience: doc.experience_years
                  ? `${doc.experience_years} yrs`
                  : doc.experience || "5+ yrs",

                nextAvailable:
                  doc.next_available || doc.nextAvailable || "Today Available",

                teleconsult: doc.teleconsult ?? true,

                // IMPORTANT:
                // Image returned directly by Laravel
                image: doc.image || null,
              };

              return <DoctorCard key={doc.id} doctor={formattedDoctor} />;
            })}
          </div>
        )}
        {!loading && !error && filteredDoctors.length === 0 && (
          <div
            className="
                bg-white
                rounded-2xl
                p-12
                text-center
                border border-[#E2E8F0]
                shadow-sm
              "
          >
            <h3
              className="
                  text-lg
                  font-bold
                  text-[#0F172A]
                "
            >
              No doctors found
            </h3>

            <p
              className="
                  text-[#64748B]
                  text-sm
                  mt-1
                "
            >
              Try adjusting your search terms or selecting a different
              specialty.
            </p>
          </div>
        )}
        {/* ==========================================
            LOADING
        ========================================== */}
        {!loading && !error && totalDoctors > 0 && (
          <div
            className="
                  mt-10
                  flex flex-col
                  sm:flex-row
                  sm:items-center
                  sm:justify-between
                  gap-4
                  bg-white
                  px-5 py-4
                  rounded-2xl
                  border border-[#E2E8F0]
                  shadow-sm
                "
          >
            <span className="text-xs text-[#64748B]">
              Showing{" "}
              <strong className="text-[#0F172A]">{doctors.length}</strong> of{" "}
              <strong className="text-[#0F172A]">{totalDoctors}</strong> doctors
            </span>

            {/* Pagination */}
            <div className="flex items-center gap-2">
              {/* Previous */}
              <button
                type="button"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className={`
                      w-9 h-9
                      rounded-lg
                      border
                      flex items-center
                      justify-center
                      transition-all
                      ${
                        currentPage === 1
                          ? `
                            border-[#E2E8F0]
                            text-[#CBD5E1]
                            cursor-not-allowed
                          `
                          : `
                            border-[#E2E8F0]
                            text-[#475569]
                            hover:text-[#3F38CA]
                            hover:bg-[#F8FAFC]
                            hover:border-[#C7D2FE]
                          `
                      }
                    `}
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              {/* Page Numbers */}
              {Array.from({ length: lastPage }, (_, index) => index + 1).map(
                (page) => (
                  <button
                    key={page}
                    type="button"
                    onClick={() => handlePageChange(page)}
                    className={`
                        min-w-9 h-9 px-2
                        rounded-lg
                        font-semibold
                        text-sm
                        flex items-center
                        justify-center
                        transition-all
                        ${
                          currentPage === page
                            ? `
                              bg-[#3F38CA]
                              text-white
                              shadow-sm
                            `
                            : `
                              border border-[#E2E8F0]
                              text-[#475569]
                              hover:text-[#3F38CA]
                              hover:bg-[#F8FAFC]
                              hover:border-[#C7D2FE]
                            `
                        }
                      `}
                  >
                    {page}
                  </button>
                ),
              )}

              {/* Next */}
              <button
                type="button"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === lastPage}
                className={`
                      w-9 h-9
                      rounded-lg
                      border
                      flex items-center
                      justify-center
                      transition-all
                      ${
                        currentPage === lastPage
                          ? `
                            border-[#E2E8F0]
                            text-[#CBD5E1]
                            cursor-not-allowed
                          `
                          : `
                            border-[#E2E8F0]
                            text-[#475569]
                            hover:text-[#3F38CA]
                            hover:bg-[#F8FAFC]
                            hover:border-[#C7D2FE]
                          `
                      }
                    `}
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
